//
//  UseCaseTest.swift
//  KrungsriTechnicalTestTests
//
//  Created by MmoMiMove on 20/12/2565 BE.
//

@testable import KrungsriTechnicalTest
import UIKit
import XCTest
import Alamofire

final class UseCaseTest: XCTestCase {

    func testHaveSpaceBar() {
        let textSearch1 = " Bangkok" // flase
        let textSearch2 = "Bangkok" // true
        let textSearch3 = "Bangkok " // false
        let textSearch4 = "Bang kok" // false
        
        for i in textSearch2 {
            XCTAssertFalse(i == " ")
        }
        
    }

    func testResultSearchWithCityName() {
        let textSearch = "Bangkok"
        
        Service.shared.currentWeatherData(cityName: textSearch,
                                          completionHandler: { data in
            XCTAssertEqual(textSearch, data.name)
        }, errorHandler: { error in
            XCTAssertThrowsError(error)
        })

    }

}
