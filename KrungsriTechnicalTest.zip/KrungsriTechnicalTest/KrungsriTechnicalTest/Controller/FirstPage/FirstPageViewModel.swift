//
//  FirstPageViewModel.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import Foundation

enum TempType {
    case kelvin
    case celsius
    case fahrenheit
}

protocol FirstPageViewModelDelegate {
    func reloadData(data: WeatherModel)
}

final class FirstPageViewModel {
    
    // MARK: - Parameter
    var delegate: FirstPageViewModelDelegate?
    var data: WeatherModel?
    var tempType: TempType = .celsius
    var tempValueCel: Double = 0.00
    var tempValueFah: Double = 0.00
    var tempValueKel: Double = 0.00
    var textSearch: String = ""
    
    // MARK: - UseCase
    private lazy var currentWeatherDataUC: CurrentWeatherDataUseCase = .init()
    
    init(delegate: FirstPageViewModelDelegate) {
        self.delegate = delegate
    }
    
    // MARK: - Function
    func currentWeatherData(cityName: String) {
        self.currentWeatherDataUC.execute(.init(cityName: cityName,
                                                completion: { [weak self] weatherData in
            self?.data = weatherData
            self?.delegate?.reloadData(data: weatherData)
        }, error: { error in
            print(error)
        }))
    }
    
    // ฟังก์ชันสำหรับแปลงหน่วยอุณหภูมิ
    public func convertTemperature(temp: Double) -> String {
        
        switch(self.tempType) {
        case .kelvin:
            let cels = round((temp) - 272.15)
            self.tempValueCel = cels
            return "\(cels) °C"
        case .celsius:
            let fahr = round((temp - 32.00) * 0.56)
            self.tempValueFah = fahr
            return "\(fahr) °F"
        case .fahrenheit:
            let cels = round((temp * 1.80) + 32.00)
            self.tempValueCel = cels
            return "\(cels) °C"
        }
        
    }
}
