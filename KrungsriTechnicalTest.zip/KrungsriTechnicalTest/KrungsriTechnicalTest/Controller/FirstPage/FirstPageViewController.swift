//
//  FirstPageViewController.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import UIKit
import IQKeyboardManagerSwift

class FirstPageViewController: UIViewController, UINavigationBarDelegate {
    
    // MARK: - New Instance
    class func newInstance() -> FirstPageViewController {
        let viewController = FirstPageViewController(nibName: "FirstPageViewController",
                                         bundle: nil)
        
        let viewModel = FirstPageViewModel(delegate: viewController)
        viewController.viewModel = viewModel
        
        return viewController
    }
    
    // MARK: - IBOutlet
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var tfSearchName: UITextField!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var imageWeather: UIImageView!
    @IBOutlet weak var viewTemperature: UIView!
    @IBOutlet weak var lblTemperature: UILabel!
    @IBOutlet weak var viewHumidity: UIView!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var viewImageViewWeather: UIView!
    @IBOutlet weak var btnConvertTemp: UIButton!
    @IBOutlet weak var lblDescription: UILabel!
    
    // MARK: - Parameters
    private var viewModel: FirstPageViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupView()
        self.setupNavigationBar()
        
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = false
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        
        self.viewImageViewWeather.isHidden = true
        self.viewTemperature.isHidden = true
        self.viewHumidity.isHidden = true
        self.btnConvertTemp.isHidden = true
        self.lblDescription.isHidden = true
        
        // MARK: - Default Data
        self.viewModel?.currentWeatherData(cityName: "Bangkok")
        self.viewModel?.textSearch = "Bangkok"
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        IQKeyboardManager.shared.enable = false
    }
    
    // MARK: - Function
    func setupView() {
        self.navigationBar.delegate = self
        
        self.tfSearchName.delegate = self
        self.tfSearchName.attributedPlaceholder = NSAttributedString(
            string: "Search City Name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray]
        )
        
        self.viewImageViewWeather.layer.cornerRadius = 10
        self.viewImageViewWeather.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        self.viewImageViewWeather.clipsToBounds = true
        self.viewTemperature.layer.cornerRadius = 10
        self.viewTemperature.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        self.viewTemperature.clipsToBounds = true
        self.viewHumidity.layer.cornerRadius = 10
        self.viewHumidity.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        self.viewHumidity.clipsToBounds = true
        self.btnConvertTemp.layer.cornerRadius = 10
        self.btnConvertTemp.clipsToBounds = true
    }
    
    func setupNavigationBar() {
        let navItem = UINavigationItem()
        let rightBtn = UIBarButtonItem(title: "next",
                                       style: .done,
                                       target: self,
                                       action: #selector(seeForecast))

        navItem.title = "Weather"
        navItem.rightBarButtonItem = rightBtn
        self.navigationBar.setItems([navItem], animated: false)
    }
    
    @objc func seeForecast() {
        let vc = SecondPageViewController.newInstance(cityName: self.viewModel?.textSearch ?? "")
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    
    // ฟังก์ชันสำหรับเปลี่ยน state หน่วยอุณหภูมิ
    func setTemp() {
        let type = self.viewModel?.tempType
        
        switch(type) {
        case .kelvin:
            self.lblTemperature.text = self.viewModel?.convertTemperature(temp: self.viewModel?.tempValueKel ?? 0.00)
            self.viewModel?.tempType = .celsius
            self.btnConvertTemp.setTitle("Convert To (°F)", for: .normal)
            break
        case .celsius:
            self.lblTemperature.text = self.viewModel?.convertTemperature(temp: self.viewModel?.tempValueCel ?? 0.00)
            self.viewModel?.tempType = .fahrenheit
            self.btnConvertTemp.setTitle("Convert To (°C)", for: .normal)
            break
        case .fahrenheit:
            self.lblTemperature.text = self.viewModel?.convertTemperature(temp: self.viewModel?.tempValueFah ?? 0.00)
            self.viewModel?.tempType = .celsius
            self.btnConvertTemp.setTitle("Convert To (°F)", for: .normal)
            break
        case .none:
            break
        }
        
    }
    
    // MARK: - Action
    @IBAction func onTapConvertTemp(_ sender: UIButton) {
        self.setTemp()
    }
    
}

extension FirstPageViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let text = textField.text ?? ""
        
        if !text.isEmpty {
            self.viewModel?.currentWeatherData(cityName: text)
        }
        
        self.viewModel?.textSearch = text
        
        view.endEditing(true)
        
        return true
    }
        
}

extension FirstPageViewController: FirstPageViewModelDelegate {
    func reloadData(data: WeatherModel) {
        
        if !data.name.isEmpty {
            self.viewImageViewWeather.isHidden = false
            self.viewTemperature.isHidden = false
            self.viewHumidity.isHidden = false
            self.btnConvertTemp.isHidden = false
            self.lblDescription.isHidden = false
            
            self.lblCityName.text = data.name
            
            self.viewModel?.tempValueKel = data.main?.temp ?? 0.00
            self.viewModel?.tempType = .kelvin
            self.setTemp()
            
            for item in data.weather {
                self.lblDescription.text = item.description
                
                let url = URL(string: "http://openweathermap.org/img/wn/\(item.icon)@2x.png")!
                DispatchQueue.main.async {
                    if let data = try? Data(contentsOf: url) {
                        let image: UIImage = UIImage(data: data)!
                        self.imageWeather.image = image
                    }
                }
            }
            
            guard let hum = data.main?.humidity else { return }
            self.lblHumidity.text = "\(hum)"
        } else {
            self.lblCityName.text = "Search Not Found"
            
            self.viewImageViewWeather.isHidden = true
            self.viewTemperature.isHidden = true
            self.viewHumidity.isHidden = true
            self.btnConvertTemp.isHidden = true
            self.lblDescription.isHidden = true
        }
        
    }
}
