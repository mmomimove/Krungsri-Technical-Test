//
//  ServiceURLs.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import Foundation

class ServiceURLs {
    
    static var BASE_API: String {
        return "https://api.openweathermap.org/data/2.5"
    }
    
    static var CURRENT_WEATHER_DATA: String {
        return BASE_API + "/weather?q={city name}&appid={API key}"
    }
    
    static var FORECAST_DATA: String {
        return BASE_API + "/forecast?q={city name}&appid={API key}"
    }
    
}
