//
//  CurrentWeatherDataUC.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 18/12/2565 BE.
//

import Foundation

public struct CurrentWeatherDataUseCaseParameter {
    
    let cityName: String
    let completion: ((WeatherModel) -> Void)
    let error: ((Error) -> Void)
    
    init(cityName: String,
         completion: @escaping (WeatherModel) -> Void,
         error: @escaping (Error) -> Void) {
        self.cityName = cityName
        self.completion = completion
        self.error = error
    }
    
}

public class CurrentWeatherDataUseCase {
    public func execute(_ param: CurrentWeatherDataUseCaseParameter) {
        Service.shared.currentWeatherData(cityName: param.cityName) { weatherData in
            param.completion(weatherData)
        } errorHandler: { error in
            param.error(error)
        }
    }
}
