//
//  ForecastDataUC.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 18/12/2565 BE.
//

import Foundation

public struct ForecastDataUseCaseParameter {
    
    let cityName: String
    let completion: (([WeatherModel]) -> Void)
    let error: ((Error) -> Void)
    
    init(cityName: String,
         completion: @escaping ([WeatherModel]) -> Void,
         error: @escaping (Error) -> Void) {
        self.cityName = cityName
        self.completion = completion
        self.error = error
    }
    
}

public class ForecastDataDataUseCase {
    public func execute(_ param: ForecastDataUseCaseParameter) {
        Service.shared.forecastData(cityName: param.cityName) { forecastData in
            param.completion(forecastData)
        } errorHandler: { error in
            param.error(error)
        }
    }
}
