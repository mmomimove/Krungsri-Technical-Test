//
//  Service.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import Foundation
import Alamofire
import SwiftyJSON

class Service {
    
    static let shared: Service = Service()
    
    let apiKey = "6c67ae4114c0d40f6ade19c4e4b48396"
    
    func currentWeatherData(cityName: String,
                            completionHandler: @escaping (WeatherModel) -> Void,
                            errorHandler: @escaping (Error) -> Void) {
        
        var url = ServiceURLs.CURRENT_WEATHER_DATA
        url = url.replacingOccurrences(of: "{city name}", with: "\(cityName)")
        url = url.replacingOccurrences(of: "{API key}", with: "\(self.apiKey)")
        
        AF.request(url).responseJSON { responseData in
            DispatchQueue.main.async {
                switch responseData.result {
                case .success(let value):
                    let json = JSON(value)
                    let dataModel = WeatherModel.init(json: json)
                    completionHandler(dataModel)
                case .failure(let error):
                    errorHandler(error)
                }
            }
        }
        
    }
    
    func forecastData(cityName: String,
                      completionHandler: @escaping ([WeatherModel]) -> Void,
                      errorHandler: @escaping (Error) -> Void) {
        
        var url = ServiceURLs.FORECAST_DATA
        url = url.replacingOccurrences(of: "{city name}", with: "\(cityName)")
        url = url.replacingOccurrences(of: "{API key}", with: "\(self.apiKey)")
        
        AF.request(url).responseJSON { responseData in
            DispatchQueue.main.async {
                switch responseData.result {
                case .success(let value):
                    let json = JSON(value)["list"]
                    let data = json.arrayValue.map({ WeatherModel.init(json: $0) })
                    completionHandler(data)
                case .failure(let error):
                    errorHandler(error)
                }
            }
        }
    }
    
}

