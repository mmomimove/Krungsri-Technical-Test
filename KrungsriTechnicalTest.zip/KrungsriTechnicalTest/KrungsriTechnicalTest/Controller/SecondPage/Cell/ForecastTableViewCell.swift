//
//  ForecastTableViewCell.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 18/12/2565 BE.
//

import UIKit

class ForecastTableViewCell: UITableViewCell {
    
    @IBOutlet weak var viewContent: UIStackView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTemperature: UILabel!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var imageViewWeather: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.viewContent.layer.cornerRadius = 10
        self.viewContent.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        self.viewContent.clipsToBounds = true
    }

    func setData(data: WeatherModel?) {
        
        guard let data = data else { return }
        let cels = round((data.main?.temp ?? 0.0) - 272.15)
        self.lblTemperature.text = "\(cels) °C"
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd MMM yyyy"
        self.lblDate.text = dateFormatterGet.string(from: data.date ?? Date())
        
        for item in data.weather {
            let url = URL(string: "http://openweathermap.org/img/wn/\(item.icon)@2x.png")!
            DispatchQueue.main.async {
                if let data = try? Data(contentsOf: url) {
                    let image: UIImage = UIImage(data: data)!
                    self.imageViewWeather.image = image
                }
            }
        }
        
        guard let hum = data.main?.humidity else { return }
        self.lblHumidity.text = "\(hum)"
        
    }
    
}
