//
//  SecondPageViewController.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import UIKit

class SecondPageViewController: UIViewController {
    
    // MARK: - New Instance
    class func newInstance(cityName: String) -> SecondPageViewController {
        let viewController = SecondPageViewController(nibName: "SecondPageViewController",
                                         bundle: nil)
        
        let viewModel = SecondPageViewModel(delegate: viewController,
                                            cityName: cityName)
        viewController.viewModel = viewModel
        
        return viewController
    }
    
    // MARK: - IBOutlet
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Parameters
    private var viewModel: SecondPageViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupView()
        self.setupNavigationBar()
        
        self.viewModel?.forecastData()
    }
    
    // MARK: - Function
    func setupView() {
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "ForecastTableViewCell", bundle: nil),
                                forCellReuseIdentifier: "ForecastTableViewCell")
    }
    
    func setupNavigationBar() {
        let navItem = UINavigationItem()
        let leftBtn = UIBarButtonItem(title: "back",
                                       style: .done,
                                       target: self,
                                       action: #selector(dismissView))
        
        

        navItem.title = "5-Day Forecast"
        navItem.leftBarButtonItem = leftBtn
        self.navigationBar.setItems([navItem], animated: false)
    }
    
    @objc func dismissView() {
        self.dismiss(animated: true)
    }

}

extension SecondPageViewController: UITableViewDataSource,
                                    UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.viewModel?.data.count == 0 {
            return 0
        } else {
            return self.viewModel?.filterDate.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ForecastTableViewCell.self), for: indexPath) as? ForecastTableViewCell {
            cell.selectionStyle = .none
            cell.setData(data: self.viewModel?.filterDate[indexPath.row])
            
            return cell
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }

}

extension SecondPageViewController: SecondPageViewModelDelegate {
    func reloadData() {
        if self.viewModel?.data.count == 0 {
            self.lblCityName.text = "Search Not Found"
        } else {
            self.lblCityName.text = self.viewModel?.cityName
        }
        
        self.tableView.reloadData()
    }
    
}
