//
//  SecondPageViewModel.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import Foundation

protocol SecondPageViewModelDelegate {
    func reloadData()
}

class SecondPageViewModel {
    
    // MARK: - Parameter
    var delegate: SecondPageViewModelDelegate?
    var cityName: String = "Bangkok"
    var data: [WeatherModel] = []
    var filterDate: [WeatherModel] = []
    
    // MARK: - UseCase
    private lazy var forecastDataDataUC: ForecastDataDataUseCase = .init()
    
    init(delegate: SecondPageViewModelDelegate,
         cityName: String) {
        self.cityName = cityName
        self.delegate = delegate
    }
    
    // MARK: - Function
    func forecastData() {
        self.forecastDataDataUC.execute(.init(cityName: self.cityName,
                                              completion: { [weak self] forecastData in
            self?.data = forecastData
            self?.filterDateData()
            self?.delegate?.reloadData()
        }, error: { error in
            print(error)
        }))
    }
    
    // ฟังก์ชันสำหรับกรองวันที่เพื่อพยากรณ์อากาศ 5 วัน
    // ตอนนี้เท่าที่ตรวจสอบยังมีบางเคสที่แสดงการพยากรณ์ไม่ครบ 5 วัน เนื่องจากข้อมูลที่ได้มีไม่ครบถ้วน
    func filterDateData() {
        
        guard self.data.isEmpty == false else { return }
        self.filterDate.removeAll()
        
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy MM dd"
        
        let date = Date() // current date
        var toString = dateFormat.string(from: date)
        
        for (index, item) in self.data.enumerated() {
            let toString2 = dateFormat.string(from: item.date ?? Date())
            
            if toString.compare(toString2) == .orderedAscending {
                toString = toString2
                self.filterDate.append(self.data[index])
            }
        }
        
    }

}

