//
//  DataModel.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 18/12/2565 BE.
//

import Foundation
import SwiftyJSON

class WeatherModel {
    var main: Main? = nil
    var id: Int = 0
    var name: String = ""
    var weather: [Weather] = []
    var date: Date?
    
    init(json: JSON) {
        self.main = Main.init(json: json["main"])
        self.id = json["id"].intValue
        self.name = json["name"].stringValue
        self.weather = json["weather"].arrayValue.map({ Weather(json: $0) })
        self.date = json["dt_txt"].dateValue
    }
    
}


class Weather {
    var icon: String = ""
    var main: String = ""
    var id: Int = 0
    var description: String = ""

    init(json: JSON) {
        self.icon = json["icon"].stringValue
        self.main = json["main"].stringValue
        self.id = json["id"].intValue
        self.description = json["description"].stringValue
    }
}

class Main {
    var temp: Double = 0.0
    var humidity: Int = 0
    var feelsLike: Double = 0.0

    init(json: JSON) {
        self.temp = json["temp"].doubleValue
        self.humidity = json["humidity"].intValue
        self.feelsLike = json["feels_like"].doubleValue
    }
}

extension JSON {
    
    public var dateValue: Date? {
        get {
            switch self.type {
            case .string:
                let formatter = DateFormatter()
                formatter.locale = Locale(identifier: "en_US")
                formatter.timeZone = TimeZone(identifier: "UTC")
                
                if self.stringValue.contains("T") {
                    if self.stringValue.contains(".") {
                        if self.stringValue.contains("Z") {
                            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
                        } else {
                            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                        }
                    } else {
                        if self.stringValue.contains("Z") {
                            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
                        } else {
                            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
                        }
                    }
                } else {
                    if self.stringValue.contains(".") {
                        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS'Z'"
                    } else {
                        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss'Z'"
                    }
                }
                
                let date = formatter.date(from: self.stringValue)

                return date
            default:
                return nil
            }
        }
    }
    
}
