//
//  ViewController.swift
//  KrungsriTechnicalTest
//
//  Created by MmoMiMove on 17/12/2565 BE.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5,
                                      execute: {
            let vc = FirstPageViewController.newInstance()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true)
        })
        
    }
    
}
